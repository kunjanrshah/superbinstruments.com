<?php

require_once( 'class-itsec-strong-passwords.php' );
