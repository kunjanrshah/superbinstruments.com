<?php

require_once( 'class-itsec-online-files.php' );
$itsec_online_files = new ITSEC_Online_Files();
$itsec_online_files->run();
